
import java.util.ArrayList;

public class CountUp {

    public static int count = 0;
    public static Integer thread_lock = 0;

    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier() {
        // TODO
        count++;
        try {
            synchronized (thread_lock) {

                if (count > 3) {
                    thread_lock.notifyAll();
                    count = 0;
                } else {
                    thread_lock.wait();
                }
            }
        } catch (Exception e) {
            //
        }
    }
}

class CountThread extends Thread {

    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
