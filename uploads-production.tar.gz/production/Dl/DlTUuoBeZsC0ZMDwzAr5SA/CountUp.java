

import java.util.ArrayList;

public class CountUp {
	static int threadCount = 0;
	static Object lock = new Object();
	public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }
	
    public static void barrier() {
        
    	synchronized (lock) {
			try {
				
				CountUp.threadCount++;
				if(CountUp.threadCount >= 4){
					CountUp.threadCount = 0;
					lock.notifyAll();
				}
				else
					lock.wait();
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
