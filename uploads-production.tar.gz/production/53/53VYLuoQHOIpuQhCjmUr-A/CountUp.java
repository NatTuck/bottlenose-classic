

import java.util.ArrayList;

public class CountUp {
    
    public static int counter = 0; // Counter to monitor number of Threads
    private static final Object lock = new Object(); // Object to get the lock on threads
    
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier() {
        // TODO
        
        synchronized(lock){
            
            try{
            	// Block first three threads
            	CountUp.counter++;
		        if(CountUp.counter < 4){
		            lock.wait();
		        }else{
		        	// Wake up all previous three blocked threads
		        	CountUp.counter = 0; // Set thread counter to zero
		            lock.notifyAll();
		        }
            }catch(Exception e){
	            e.printStackTrace();
	        }
        }
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
