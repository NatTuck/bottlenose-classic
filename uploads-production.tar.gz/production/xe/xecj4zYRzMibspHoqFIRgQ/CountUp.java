
import java.util.ArrayList;
import java.util.List;

public class CountUp {

    static int noOfThreadsExecuted = 0;

    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static String lockObject = "";
    public static void barrier() {
        // TODO

            noOfThreadsExecuted++;


                synchronized (lockObject){

                    if(noOfThreadsExecuted < 4){
                    try{
                    lockObject.wait();
                }

                    catch (Exception name) {

                    }

            }else{
                        lockObject.notifyAll();
                        noOfThreadsExecuted = 0;

                    }

        }

    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}