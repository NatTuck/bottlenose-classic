package com.neu.cd6240.practice;

import java.util.ArrayList;

public class CountUp {
	static Object lock = new Object();
	static int counter =0;
	
    public static void main(String[] args) throws Exception {
    	
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier() throws InterruptedException {
        // TODO
    	// synchronized, .wait, .notifyAll
    	// number of threads is known. constant4
    	
    	synchronized(lock){
    	try {
			counter++;
			if(counter >= 4){
				counter = 0;
			lock.notifyAll();
			
			}
			else{
				lock.wait();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	}
    	
    	
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            try {
				CountUp.barrier();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }
}