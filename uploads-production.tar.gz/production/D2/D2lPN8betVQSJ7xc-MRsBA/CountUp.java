/**
 * Created by ramasubramanianchandrasekar on 9/16/16.
 */
import java.util.ArrayList;

public class CountUp {

    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    static int count;

    public synchronized static void barrier() {
        // tools: synchronized, .wait, .notifyAll
        // Number of threads is known, constant
        count++;

        try
        {
            if(count >= 4) {
                CountUp.class.notifyAll();
                count = 0;
                return;
            }
            else {
                CountUp.class.wait();
            }
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class CountThread extends Thread {
    @Override
    public void run(){
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
