#!/usr/bin/env ruby
require 'bn_grade'
require 'time'

correct = "0 0 0 0 1 1 1 1 2 2 2 2 3 3 3 3 4 4 4 4"

score = BnScore.new
unpack_submission

system("javac CountUp.java")
outp = `java CountUp`.gsub(/\n/, " ").strip

score.test("correct", 1) do
  if outp == correct
    1
  else
    0
  end
end

score.test("on time", 1) do
  if Time.now < Time.parse("2016-09-16 17:00:00 -0400")
    1
  else
    0
  end
end

score.output!
