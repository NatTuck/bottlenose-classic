
import java.util.ArrayList;

public class CountUp {

    private static final Object lock = new Object();

    private static int thread_limit = 0;

    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier() {
        synchronized(lock){
          /*  thread_limit++;
          if(thread_limit < 4){

            try{
              lock.wait();
            }catch(InterruptedException e){
              System.out.println("Error caught");
            }
          }
          else{

            thread_limit = 0;
            lock.notifyAll();
            */
            thread_limit++;
            while(thread_limit < 4){

              try{
                lock.wait();
              }catch(InterruptedException e){
                e.printStackTrace();
              }

            }

              thread_limit = 0;
              lock.notifyAll();
          





        }
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
