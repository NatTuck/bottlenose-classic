#!/usr/bin/ruby

def hello(name)
  "Hello, #{name}"
end

puts hello("Bob")
