
import java.util.ArrayList;

public class CountUp {
    public static int count;
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier() {
        CountUp.checkLock();
    }

    public static synchronized void checkLock() {
        try {
            count++;
            if (count <4){
                CountUp.class.wait();
            } else {
                CountUp.class.notifyAll();
                count=0;
            }
        } catch (Exception e) {
        }

    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
