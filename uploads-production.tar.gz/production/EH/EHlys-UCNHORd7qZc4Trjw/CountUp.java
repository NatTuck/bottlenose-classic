import java.util.concurrent.atomic.AtomicInteger;

import java.util.ArrayList;

public class CountUp {
	public  static int k= 0;
	public static String lockObj="";
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static  void barrier(){
		synchronized(lockObj) {
			if(k<=2){ 
				k++;
				try{     
					lockObj.wait();
				}
				catch(Exception exception){
				}
			}
			else{
				k = 0;
				lockObj.notifyAll();
			}    	
		}
	}
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
