package mr.inclass1;



import java.util.ArrayList;

public class CountUp {
	public static int count =0;
	public final static Object obj = new Object();
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public  static void barrier() throws InterruptedException {
        // TODO
    	synchronized(obj)
    	{
    		count++;
    		if(count%4==0)
        	{
        		obj.notifyAll();
        		
        	}
    		else
    			obj.wait();
    	}
    	
    	
    	
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            try {
				CountUp.barrier();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }
}
