
import java.util.ArrayList;

public class CountUp {
	
	static int counter = 0,thread_count = 0;
	
	public static Double lock_obj = 0.0;
	
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        thread_count = ts.size();
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
                
    }

    public static void barrier() throws InterruptedException{
        // TODO
    	counter ++;  
    	synchronized(lock_obj){
    	if(counter  >= thread_count) {
    		lock_obj.notifyAll();    		
    		counter = 0;
    		return;
    	}else    		
    		lock_obj.wait();
    	}
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
					try {
						CountUp.barrier();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
        }
    }
}
