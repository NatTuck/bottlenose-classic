import java.util.ArrayList;

public class CountUp {
	static int NUMBER_OF_THREADS = 4;
	static int counter = 1;
	private static final Object lock = new Object();

	public static void main(String[] args) throws Exception {
		ArrayList<CountThread> ts = new ArrayList<CountThread>();

		for (int ii = 0; ii < 4; ++ii) {
			ts.add(new CountThread());
		}

		for (int ii = 0; ii < 4; ++ii) {
			ts.get(ii).start();
		}

		for (int ii = 0; ii < 4; ++ii) {
			ts.get(ii).join();
		}
	}

	public static void barrier() throws InterruptedException {		
		synchronized (lock) {
			if (counter >= NUMBER_OF_THREADS) {
				counter = 1;
				lock.notifyAll();
				return;
			} else 
			{
				counter++;
				lock.wait();
			}
		}
	}
}


class CountThread extends Thread {
	 @Override
	    public void run() {
	        for (int ii = 0; ii < 5; ++ii) {
	            System.out.println("" + ii);
	            try {
					CountUp.barrier();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	    }
}
