package hadoop_test;


import java.util.ArrayList;

public class CountUp {
	public static int cnt;
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public synchronized static void barrier() {
        // TODO
    	 CountUp thr = new CountUp();
    	 
    	 cnt ++;
       if(cnt >= 4){
            CountUp.class.notifyAll();
            if(cnt >= 4){
         	   cnt = 0;
            }
            return;
       }
      
       else{
    	   try {
			CountUp.class.wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       }
    }
    

    
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
