
import java.util.ArrayList;
import java.lang.InterruptedException;

public class CountUp {
	public static int threadCount = 4;
	public static int waitingThreadCount = 0;

	public static final Object lock = new Object();

    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < threadCount; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < threadCount; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < threadCount; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier() {
    	try {
			synchronized(lock) {
       			if (waitingThreadCount != threadCount - 1) {
	       			waitingThreadCount++;
	       			lock.wait();
	       		}

	       		else {
					waitingThreadCount = 0;
	       			lock.notifyAll();
	       		}
	   		}
    	}
    	catch(InterruptedException e) {}
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
