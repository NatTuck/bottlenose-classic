
import java.util.ArrayList;

public class CountUp {
	public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }
	// Counter for keep track of number of threads that enter barrier
	static int numthreads;
	
    public static synchronized void barrier() {
    	// TODO
    	// Each thread increments the counter and if its the last one
    	// to enter, notifies all threads waiting
    	++numthreads;
    	if (numthreads >= 4) {
    		CountUp.class.notifyAll();
    		// reset the counter
    		numthreads = 0;
    	}
    	else {
    		try {
			// wait for other threads
    			CountUp.class.wait();
    		} catch(InterruptedException e) {}
    	}
    			
    }  
}

class CountThread extends Thread {
    @Override
    public void run() {
    	for (int ii = 0; ii < 5; ++ii) {
    			System.out.println("" + ii);
    			CountUp.barrier();
    		}
    }
}
