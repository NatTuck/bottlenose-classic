
import java.util.ArrayList;

public class CountUp {
    public static int counter=0;
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }
    
    public static String lock="";

    public static  void barrier(){
        counter++;
        synchronized(lock){
            if(counter<4){
                try{
                lock.wait();
                }catch(Exception e){}
            }
            else{
                lock.notifyAll();
                counter=0;
            }
        }

    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
