import java.lang.management.LockInfo;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.util.ArrayList;

public class CountUp {
    public static int count = 0;
    public static Integer lock = 0;

    
	public static void main(String[] args) throws Exception {
		ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
         
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public  static void barrier() {
    	count++;
    
    	synchronized(lock){	
    		try {
    				
		    	if(CountUp.count > 3){
		      		 lock.notifyAll();
		      		 CountUp.count = 0;
		      
		      	 } else{
		
		      		lock.wait();
		      	 }
			} catch (Exception e) {
				e.printStackTrace();
			}
    	}
    }
}
    
class CountThread extends Thread {
    
    @Override
    public void run() {
    	  for (int ii = 0; ii < 5; ++ii) {
    		  System.out.println("" + ii);
           	  CountUp.barrier();
    	  }
    	  
    }
}
