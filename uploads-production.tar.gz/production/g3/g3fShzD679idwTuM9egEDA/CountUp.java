
import java.util.ArrayList;

public class CountUp {
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }
    
    private static int[] count={0,0,0,0,0};

    public static void barrier(int ii) throws InterruptedException {
        // TODO
    	//tools: synchronized, .wait, .notifyAll
    	//incrementCount();
    	/*
    	if(count == 4) {
    		wait();
    	} else {
    		notifyAll();
    	}
    	*/
    	synchronized(count) {
    		count[ii]++;
    		
    		if(count[ii] == 4) {
    			count.notifyAll();        		
        	} else {
        		//System.out.println("counts: " + count[ii]);
        		count.wait();
        	}
    		
    	}
    	
    	
    }
    /*
    public static synchronized void incrementCount() {
        count++;
    }
    */
    
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
			try {
				CountUp.barrier(ii);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }
}
