
import java.util.ArrayList;

public class CountUp {
    static volatile int counter = 0;
    static Object obj = new Object();
    static final int MAX_THREADS_WAITING = 3;

    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier() {
        // TODO
        try {
            synchronized (obj) {
                if (counter < MAX_THREADS_WAITING) {
                    counter = counter + 1;
                    obj.wait();
                } else {
                    counter = 0;
                    obj.notifyAll();
                }
            }
        } catch (Exception e) {}
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
