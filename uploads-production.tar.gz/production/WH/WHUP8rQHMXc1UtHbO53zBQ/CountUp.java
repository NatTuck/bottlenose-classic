
import java.util.ArrayList;

public class CountUp {
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }
	
    static int numThread = 4;
    private static Object lock = new Object();
    public static void barrier() {
	// sychronized wait notifyAll 
        synchronized(lock) {
	    numThread--;
	    try {
	    	if(numThread > 0)
			lock.wait();
	    	else {
			numThread = 4;
			lock.notifyAll();
	    	}
	    } catch(Exception e) {
	    
            }
	}

    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
	    CountUp.barrier();
        }
    }
}
