package threads;

/**
 * Created by dishasoni on 9/16/16.
 */

import java.util.ArrayList;

public class CountUp {
   
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();


        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }


        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    static int count = 0;

    public synchronized static void barrier() {
        // TODO
       // CountUp c = new CountUp();
        count++;
        if (count >= 4) {
            CountUp.class.notifyAll();
            count = 0;
            return;
        } else {
            try {

                CountUp.class.wait();


            } catch (InterruptedException e) {
                // silently ignore
            }
        }

        //System.out.println("hello");
    }

}
class CountThread extends Thread {
    @Override
    public void run(){
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
