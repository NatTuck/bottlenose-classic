
import java.util.ArrayList;

public class CountUp {
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    static int    nn = 0;
    static Object mx = new Object();

    public static void barrier() {
        synchronized (mx) {
            nn++;

            if (nn == 4) {
                nn = 0;
                mx.notifyAll();
            }
            else {
                try {
                    mx.wait();
                }
                catch (Exception _ee) {
                }
            }
        }
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
