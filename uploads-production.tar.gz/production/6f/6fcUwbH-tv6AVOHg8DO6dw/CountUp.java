
import java.util.ArrayList;

public class CountUp {
	public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }
    
    final static Object lockObject = new Object();
    static int counter = 0;

    public static void barrier() {
        // TODO
    	counter += 1; 
    	//System.out.println("" + counter);
    	synchronized(lockObject){
		if (counter < 4){
			try {
				lockObject.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{
			counter = 0;
			lockObject.notifyAll();
			
		}
    }
		
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
