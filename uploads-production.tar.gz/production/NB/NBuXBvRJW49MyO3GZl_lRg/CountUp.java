
import java.util.ArrayList;

public class CountUp {
    public static int count = 0;
    private static final Object lock = new Object();
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier(){
        synchronized(lock) {
            try{
                ++count;
                if (count < 4){
                    lock.wait();
                }
                else{
                    count = 0;
                    lock.notifyAll();
                }
            }
            catch(InterruptedException e){
                e.printStackTrace();
            }
        }
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }          
    }
}
