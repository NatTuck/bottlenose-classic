
import java.util.ArrayList;

public class CountUp {
	
    

	public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }
	
// code updates from here on
	
	static int counter = 0;

    public synchronized static void barrier() {
    	
    	counter++;
    	
		if(counter >= 4){
			CountUp.class.notifyAll();
			counter = 0;
		} else{
        	try {
        		CountUp.class.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
