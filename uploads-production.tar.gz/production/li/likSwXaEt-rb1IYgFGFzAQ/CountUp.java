
import java.util.ArrayList;

public class CountUp {
    private static final int NUM_THREADS = 4;
    private static int barrier_count = 0;
    private static final Object lock = new Object();

    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < NUM_THREADS; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < NUM_THREADS; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < NUM_THREADS; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier() {
        synchronized(lock) {
            barrier_count++;
            if (barrier_count >= NUM_THREADS) {
                barrier_count = 0;
                lock.notifyAll();
                return;
            } else {
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
