
import java.util.ArrayList;

public class CountUp {
    static String ObjectToBeCalled = "ObjectToBeCalled";
    static int numberOfThreads = 0;
//    tools : synchronized, wait, notifyAll
//    Number of threads is known
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }

        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public static void barrier() {
        // TODO
        synchronized (ObjectToBeCalled) {
            try {
                if (numberOfThreads < 3) {
                    numberOfThreads++;
                    ObjectToBeCalled.wait();
                } else {
                    numberOfThreads = 0;
                    ObjectToBeCalled.notifyAll();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            CountUp.barrier();
        }
    }
}
