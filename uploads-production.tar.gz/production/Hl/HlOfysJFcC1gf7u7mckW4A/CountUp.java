package inclass;

import java.util.ArrayList;

public class CountUp {
	public static int counter=0;
    public static void main(String[] args) throws Exception {
        ArrayList<CountThread> ts = new ArrayList<CountThread>();

        for (int ii = 0; ii < 4; ++ii) {
            ts.add(new CountThread());
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).start();
        }
        
        for (int ii = 0; ii < 4; ++ii) {
            ts.get(ii).join();
        }
    }

    public synchronized static void barrier() throws InterruptedException   {
        counter++;
        
    	if(counter>=4){
    		CountUp.class.notifyAll(); 
    		counter=0;  		 		
    		return;
    		
    	}
    	else
    	{
    		CountUp.class.wait();	
    	}
    	
    	
    }
}

class CountThread extends Thread {
    @Override
    public void run() {
        for (int ii = 0; ii < 5; ++ii) {
            System.out.println("" + ii);
            try {
				CountUp.barrier();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }
}
